﻿using System.Text;

namespace TheBrainChallenge1;

public class Calculator {
	public Calculator() {
	}

	public string Square(int size) {
		StringBuilder line = new();
		for(int n = 0; n < size; n++) {
			line.Append('*');
		}

		StringBuilder output = new();
		for(int n = 0; n < size; n++) {
			output.Append(line + "\n");
		}

		return output.ToString();
	}
	
	public string Circle(int size) {
		// TODO: Make magic happen here
		return "";
	}
}
